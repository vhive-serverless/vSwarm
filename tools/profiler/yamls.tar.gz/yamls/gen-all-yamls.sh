#!/bin/bash

COMMAND="python3 generate-yamls.py"

for dir in */; do
  if [ -d "$dir" ]; then
    (cd "$dir" && $COMMAND)
  fi
done
