import yaml

template_yaml = """
apiVersion: serving.knative.dev/v1
kind: Service
metadata:
  name: image-rotate-python-{x}
  namespace: default
spec:
  template:
    metadata:
      annotations:
        autoscaling.knative.dev/initial-scale: "1"  # Should start from 0, otherwise we can't deploy more functions than the node physically permits.
        autoscaling.knative.dev/min-scale: "1"  # This parameter only has a per-revision key, so it's necessary to have here in case of the warmup messes up.
        autoscaling.knative.dev/target-burst-capacity: "-1"  # Put activator always in the path explicitly.
        autoscaling.knative.dev/max-scale: "1"  # Maximum instances limit of Azure.
    spec:
      containerConcurrency: 1
      containers:
        - image: docker.io/vhiveease/relay:latest
          ports:
            - name: h2c
              containerPort: 50000
          args:
            - --addr=0.0.0.0:50000
            - --function-endpoint-url=0.0.0.0
            - --function-endpoint-port=50051
            - --function-name=image-rotate-python
            - --value=img{x}.jpg
            - --profile-function=true
        - image: docker.io/vhiveease/image-rotate-python:latest
          args:
            - --addr=0.0.0.0
            - --port=50051
            - --db_addr=mongodb://image-rotate-database:27017
"""

# List of x values
x_values = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]

# Generate YAML files for each combination of x and y values
for x in x_values:
    yaml_content = template_yaml.format(x=x)
    filename = f"kn-image-rotate-python-{x}.yaml"
    with open(filename, "w") as f:
        f.write(yaml_content)
    print(f"Created {filename}")
